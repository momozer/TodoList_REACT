export class DemoModele{
    nom: string;
    prenom : string;
    dateDeNaissance : string;

    constructor (nom : string, prenom : string, dateDeNaissance:string){
        this.nom = nom;
        this.prenom = prenom;
        this.dateDeNaissance = dateDeNaissance;
    }
}