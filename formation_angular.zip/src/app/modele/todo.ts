export class Todo{
    task : string;
    state : boolean = false;

    constructor(task :string){
        this.task=task;
    }
}